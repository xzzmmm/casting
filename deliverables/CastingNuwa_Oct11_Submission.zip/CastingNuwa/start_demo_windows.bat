@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  py -3.12 -m venv .venv
  if errorlevel 1 (
    python -m venv .venv
    if errorlevel 1 goto failed
  )
)
".venv\Scripts\python.exe" -m pip install -r requirements_demo.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" run_demo.py
if errorlevel 1 goto failed
exit /b 0
:failed
echo Demo did not start. Read SUBMISSION_README.md for setup and troubleshooting.
pause
exit /b 1
