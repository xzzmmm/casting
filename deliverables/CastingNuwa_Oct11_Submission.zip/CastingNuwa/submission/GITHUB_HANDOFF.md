# GitHub Desktop Submission Handoff

Submission repository: https://github.com/xzzmmm/casting
Sole project member: Zimiao Xiang (xzzmmm), confirmed on 10 October 2026.

The preparation checked snapshot `c48ddc8fe7bbf43221cfea707caa5bb96f4ad78f`
(29 September 2026). The repository has not been changed by this preparation step.
An API read is
not a claim that your local GitHub Desktop has already Fetched/Pulled.

## Before changing the checkout

1. Keep only one active editing session, including across different computers.
2. In GitHub Desktop select the correct repository and agreed branch.
3. Click **Fetch origin**. If offered, click **Pull origin** and finish syncing.
4. Review existing local changes and resolve any conflicts before adding files.
5. Compare the downloaded submission files with the freshly pulled checkout.
   The package is a prepared version, not permission to replace a newer checkout wholesale.

## Files prepared for review

| Files | Purpose |
|---|---|
| `app.py`, `ui_theme.py` | Refined interface; the app's changed definition relative to the inspected GitHub snapshot is `build_ui` |
| `requirements_demo.txt`, `run_demo.py`, `start_demo_windows.bat` | Minimal local demo setup and explicit sample-data mode |
| `SUBMISSION_README.md`, `submission/` | Startup instructions, individual journal, project plan and solo progress summary |
| `site/index.html` | Additional standalone sample-results preview |

All 35 other matching source files were identical to the inspected snapshot. The
package does not contain every historic generated output or archive in the remote
repository. Keep any existing `prompts/youknow.zip` and historical output; do not
delete them simply because they are absent from this package. Existing dependency
files and README should be reviewed rather than replaced unnecessarily: the demo
has its own requirements and submission instructions.

The optional `.github/` Pages workflow belongs to the earlier standalone website
preview. It is not required for the coursework's local code demo. Do not copy it into
the checkout unless you have deliberately chosen to configure Pages hosting.

## Validate, then Commit and Push through Desktop

1. In the pulled checkout install `requirements_demo.txt` and run `python run_demo.py`.
2. Complete the walkthrough in `SUBMISSION_README.md`; check JSON save/load.
3. Review the individual journal and progress summary; add the actual rehearsal result.
4. In Desktop inspect the **Changes** list. Exclude `.venv/`, `__pycache__/`, API keys,
   local `.env` and unrelated generated files.
5. Enter a truthful commit summary, for example:
   `Prepare Oct 11 local casting demo and project documentation`.
6. Click **Commit to [the agreed branch]**, then **Push origin**. A local commit alone
   does not make the changes available on GitHub.
7. Open the repository on GitHub and verify the new commit and prepared files appear.
8. Record the commit SHA in the journal and progress summary before sharing them.

This workflow follows the assignment's explicit GitHub Desktop requirement.
The assistant has not performed a Desktop commit or push in your computer session.

## Share with Fatcat1015

The repository was public when checked. Its URL can therefore be shared for viewing:
https://github.com/xzzmmm/casting

The assignment says to share the GitHub with the instructor (username **Fatcat1015**).
Sharing a public URL and inviting a collaborator are different actions. Confirm which
the course expects. If collaborator access is required, the owner uses repository
**Settings → Collaborators → Add people**, chooses the verified Fatcat1015 account
and sends an invitation; the recipient must accept it. Collaborator access carries
repository permissions, so do not add it merely to repair a webpage URL.

No invitation or instructor/group message has been sent by this preparation step.

Submission-message draft — review and fill before sending:

> My October 11 CastingNuwa demo is available at https://github.com/xzzmmm/casting.
> Submission commit: [ACTUAL PUSHED SHA].
> Startup: install `requirements_demo.txt` and run `python run_demo.py`.
> The individual journal, project plan, solo progress summary and verification notes
> are in `submission/`.
> The submitted demo uses explicitly labelled sample data; real model/media validation
> is scheduled in the follow-up project plan.

## Official reference

- Syncing in Desktop: https://docs.github.com/en/desktop/contributing-and-collaborating-using-github-desktop/syncing-your-branch
- Commit/review in Desktop: https://docs.github.com/en/desktop/making-changes-in-a-branch/committing-and-reviewing-changes-to-your-project-in-github-desktop
- Repository invitations: https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/repository-access-and-collaboration/inviting-collaborators-to-a-personal-repository
