# CastingNuwa — Individual Project Plan

Prepared: 10 October 2026. Planning period: 12 October–8 November 2026.
Project owner: **Zimiao Xiang · GitHub: xzzmmm**.
This is a proposed four-week plan; adjust dates to the course's final deadline.

## Goal and current baseline

Help a student drama group carry out a casting round with traceable role requirements,
consistent auditions, actor observation records and human-confirmed decisions.

Current code includes a six-step Gradio workflow, text inputs, production settings,
audition tasks, candidate proposals, manual confirmation and JSON save/load. Audio,
video and real API paths exist in source but are not established as working merely by
passing the sample-data text demo. The October 11 demo prioritises a local run without
model credentials. See `VALIDATION.md` for the actual checked scope.

## Milestones

**Owner of every milestone: Zimiao Xiang.** Prioritise a dependable text workflow;
reduce optional media scope if it would prevent the final demonstration.

| Week | Work | Outputs | Acceptance criteria |
|---|---|---|---|
| 12–18 Oct | Stabilise text workflow and verify the real model connection; rehearse setup on a second computer; inspect failed-call behaviour | Reproducible text demo, model configuration guide, issue list, test records | A clean setup completes the sample workflow. With an approved configured key, one real script-to-role and actor-observation run succeeds. Authentication/network failures are shown explicitly and never presented as sample analysis. |
| 19–25 Oct | Improve the evidence and candidate presentation; evaluate roles and actor observations using a small reviewed test set | Test-set specification, manually reviewed expected observations, evidence comparison report | Use at least 5 short script cases and 10 actor-text cases as a target. Check missing evidence, contradictions, duplicate names, setting changes and manual decisions. Label proposed figures as targets until the dataset actually exists. |
| 26 Oct–1 Nov | Validate optional audio/video paths; keep text mode dependable; test import/export and session separation | Dependency instructions, short media demonstration, regression results | When dependencies are available, one approved short audio file and one short video complete processing. Unavailable dependencies produce a helpful error. Frame sampling covers the full video. Two sessions do not share state. If media remains unreliable, document the limitation and preserve the completed text scope. |
| 2–8 Nov | Conduct a usability rehearsal, resolve high-priority defects and prepare the final demonstration | User feedback notes, revised UI, final README, release checklist and completed journal | A person outside the implementation role can complete the main workflow from instructions. Every confirmed choice can be traced to a reason and saved/reloaded. No unresolved critical defect blocks the final presentation. |

## Responsibilities

The project has one member. Zimiao Xiang owns integration, setup, role/audition logic,
observation evaluation, UI, documentation and progress reporting. AI assistance is
recorded separately in the journal. A usability reviewer, if available, provides
feedback and is not recorded as an implementation member.

## Work routine and weekly progress review

Follow the assignment's GitHub Desktop workflow: Fetch/Pull before work, complete
and test a bounded task, update the journal, review changes, then Commit and Push.
Keep only one active editing session, including when switching computers. A local
commit alone does not complete the push.

Proposed review dates: 18 October, 25 October, 1 November and 8 November. Record
completed work, evidence, blockers, decisions and next tasks, then send the reviewed
summary through the required course group channel.

There is no multi-member meeting to record. Confirm with the instructor whether a
weekly solo progress review meets the meeting requirement. No attendees or meetings
will be invented.

## Risks and responses

| Risk | Response |
|---|---|
| Hosted URL blocked | Rehearse a local demonstration; keep the standalone page as a supplementary preview |
| API errors, latency or cost | Separate sample mode visibly; use a small real run and bounded evaluation set |
| Media dependencies unreliable | Keep validation within its milestone and preserve the working text path |
| Conflicting versions across computers | Use one editing session; Fetch/Pull before work and Push before switching |
| Solo workload too large | Prioritise text workflow, evidence, save/load and documentation; reduce optional media scope |
| Progress record incomplete | Update factual entries after each session and attach file, commit and observed-test evidence |
