# CastingNuwa — Solo Project Journal

Reporting cut-off: 10 October 2026. Submission: 11 October 2026.
Project member and owner: **Zimiao Xiang · GitHub: xzzmmm**.
The student confirmed on 10 October that this is an individual project.
Repository: https://github.com/xzzmmm/casting

This record combines repository history and recorded AI-assisted preparation.
Historical task summaries describe commit messages; a commit author is not proof
that every line was written without assistance. Working hours were not recorded
and are not estimated. Student review and integration of the prepared package remain pending.

## 1. Development record

History inspected: 10 October 2026. Dates use Asia/Shanghai.
All listed commits are recorded under the sole member's account.

| Date | Recorded account | Work described in commit message | Evidence |
|---|---|---|---|
| 13 Sep | xzzmmm | Initial CastingNuwa application with multimodal profiling and matching | `bff7841ecf064582014d2cf8561a25e38c84584e` |
| 14 Sep | xzzmmm | Add backstage staffing analysis | `7081fee9cd39d7425b5d1409b6c17ed28aa9876e` |
| 14 Sep | xzzmmm | Add local heuristic rules and team-analyser tests | `af043948c57eea764f301b05ea3b669ba82e0701`, `10e0b44db62316fb769f773f24e54729fc0386f4` |
| 19 Sep | xzzmmm | Restructure outputs into observations and evidence-based candidate proposals | `9a9f39a85163a0c67aaee3b8337e56da217c9b19` |
| 19 Sep | xzzmmm | Add confirmed settings, two-round auditions, manual decisions, session isolation and JSON storage | `5339d38f16ca09728da833f41bb9cc6150eaf54b` |
| 22 Sep | xzzmmm | Repair callback/state/storage issues and add boundary regression checks | `16468058c83ca73c19d5794356bc872a74311241` |
| 29 Sep | xzzmmm | Add an archive and two-round audition task tests | `c48ddc8fe7bbf43221cfea707caa5bb96f4ad78f` |

Full commit links use `https://github.com/xzzmmm/casting/commit/` followed by the SHA.
Historical test claims describe the commits. Current results are in `VALIDATION.md`.

## 2. AI-assisted preparation record

These entries identify assistance provided during preparation. They do not claim
that the student personally executed the assistant's tests or has already reviewed
and committed these files.

| Date | Assistance provided | Output / verification |
|---|---|---|
| 2 Oct | Refine the Gradio workbench with a wine/ivory theme, clearer panels, responsive navigation and collapsed technical data | `ui_theme.py`, UI changes in `app.py`, standalone visual demo |
| 2 Oct | Prepare a static flow demonstration and an initial hosted preview | `site/index.html`; hosted domain later showed an access-block page, so online access was not accepted as working |
| 10 Oct | Compare the saved demo with the current GitHub snapshot | 35 repository files matched; changed application definition was `build_ui`; snapshot `c48ddc8fe7bbf43221cfea707caa5bb96f4ad78f` |
| 10 Oct | Prepare minimal dependencies, a local demo runner, Windows launch helper and submission documents | `requirements_demo.txt`, `run_demo.py`, `start_demo_windows.bat`, `submission/` |
| 10 Oct | Check the sample text workflow on Linux/Python 3.12 | UI built with 150 components and 22 event bindings; local HTTP 200; 25 existing workflow assertions passed |
| 10 Oct | Adapt submission documents to the confirmed individual project | Individual journal, four-week plan, solo progress summary and GitHub Desktop handoff |

## 3. Problems and follow-up

| Issue | Action / status |
|---|---|
| Hosted preview inaccessible | Prepare a local Python demo and supplementary standalone page; online access is not claimed as working |
| Reproducible demo setup needed | Add minimal dependencies and an explicit sample-mode runner |
| Real model and media validation pending | Schedule bounded validation in the project plan |
| Weekly meeting requirement for a solo project | Prepare a factual personal progress summary; confirm the format with the instructor |

## 4. Student's next actions

Owner for all actions: Zimiao Xiang (xzzmmm).

1. Review and understand the prepared files before submission.
2. Fetch/Pull in GitHub Desktop, compare against the current checkout and integrate selected changes.
3. Rehearse on the presenting computer, including settings, auditions, candidate confirmation and JSON save/load. Record the actual result.
4. Commit and Push through GitHub Desktop. Add the actual commit link and review/rehearsal dates after those actions happen.
5. Share the repository with the instructor and send the reviewed progress summary through the required course channel.

At this cut-off, no new submission commit, Windows rehearsal or message delivery
is claimed. No additional members or meetings are recorded.
