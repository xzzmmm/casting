# October 11 Demo — Verification Record

Run date: 10 October 2026 (Asia/Shanghai).
Environment: Linux, Python 3.12.14, Gradio 6.29.0, OpenAI SDK 2.54.0,
HTTPX 0.28.1 with SOCKS support. Dependencies were installed for this run.

| Check | Observed result |
|---|---|
| Python source syntax | All packaged Python files parsed successfully |
| `python run_demo.py --check` | UI built: 150 components and 22 event bindings |
| Actual CLI launch | `python run_demo.py --no-browser --port 7863` stayed running; `/` returned HTTP 200; `/config` contained 150 components and 22 bindings |
| Existing `test_v06_flow.py` | Exit 0; 25 assertions passed |
| Backstage sample analysis | Produced a nonempty report including lighting requirements from the sample script |
| Repository comparison | 35 packaged files matched the inspected GitHub snapshot; the changed app definition was `build_ui` |

The 25 workflow assertions cover role extraction, unconfirmed-settings blocking,
actor records, confirmed production settings, audition tasks and adjustment/retest
information, schedules, candidate proposals, manual final choice with reason, and
JSON save/load preserving roles, actors, settings, tasks and decisions.

The temporary verification server was stopped. Start the app again on the presenting
computer using `SUBMISSION_README.md`.

## Scope and remaining verification

- All analysis checks used explicit sample-data mode. Real API calls/model quality,
  speech recognition and video processing were not validated in this run.
- Local HTTP serving and callback logic were checked. No new interactive browser
  inspection or screenshot is claimed.
- The Windows launch helper was not executed on Windows. Rehearse it on the
  presenting computer before submission.
- The prior hosted preview was inaccessible to the user; deployment status is not
  accepted as proof of working online access. The local demo does not depend on it.
- The journal and plan identify the sole member. Student review, integration and
  presenting-computer rehearsal are pending. The instructor has not confirmed whether
  a solo progress summary meets the weekly meeting requirement.
- No GitHub Desktop Commit/Push, teacher invitation or group-chat message was
  performed in this preparation step.

## Baseline and integration

Repository inspected: https://github.com/xzzmmm/casting

Pinned snapshot: `c48ddc8fe7bbf43221cfea707caa5bb96f4ad78f`.
Preparation used an isolated copy and did not modify the shared repository.
Fetch/Pull in GitHub Desktop and review against the current checkout before integration.
