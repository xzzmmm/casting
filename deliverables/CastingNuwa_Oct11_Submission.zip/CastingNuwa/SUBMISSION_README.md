# CastingNuwa — October 11 code demo

**Submission deadline: 11 October 2026. The assignment does not specify a time.**

CastingNuwa is a guided drama casting application. Its six-step workflow organises
role requirements, director settings, auditions, actor observations, candidate
proposals and backstage staffing. A human director makes the final casting decision.

## Run the application

Verified interpreter: Python 3.12. Install dependencies once with internet access;
the sample-data text demo then runs locally without an API key. Audio/video packages
and real model calls are outside this demo's verified scope.

### Windows

Install Python 3.12, extract the folder, then double-click
`start_demo_windows.bat`. Keep its terminal open while demonstrating.

### Windows / macOS / Linux terminal

Open a terminal in this folder:

```sh
python -m venv .venv
```

Activate the environment:

```text
Windows PowerShell: .venv\Scripts\Activate.ps1
Windows Command Prompt: .venv\Scripts\activate.bat
macOS / Linux: source .venv/bin/activate
```

On macOS/Linux, use `python3` instead of `python` to create the environment if needed.
Then run:

```sh
python -m pip install -r requirements_demo.txt
python run_demo.py
```

Open `http://127.0.0.1:7860`. This address is on your own computer.
If port 7860 is in use, run `python run_demo.py --port 7861` and open the printed address.
If the browser does not open automatically, copy the printed address into it.

The runner explicitly selects sample-data mode, even if a local `.env` contains a
model key. The page labels demo output. Most analysis outputs use fixed mock fixtures;
backstage staffing can also use local heuristic rules. This demonstrates the working
workflow and does not establish real AI analysis quality.

To check installation without starting a server:

```sh
python run_demo.py --check
```

## A 5–7 minute demonstration

1. **Roles:** load the sample script and generate role cards. Show an observable
   requirement and its script evidence.
2. **Settings:** prefill requirements; enter style and schedule, then save/confirm.
   Explain that unconfirmed settings block candidate matching.
3. **Auditions:** generate tasks for all roles. Show the adjustment instruction and
   second-round task; export the tasks.
4. **Actor observations:** use text mode, load sample actors and generate observations.
   Point out direct observations, interpretations and items requiring verification.
5. **Candidates:** generate all proposals, select a role and an actor, write a reason,
   then confirm. Explain that the person, not the model, makes the decision.
6. **Team:** load the sample script and analyse backstage needs.
7. **Save/load:** save the project JSON and load it back. Show that saved choices persist.

The actual working app is `run_demo.py` + `app.py` + `src/` + `ui_theme.py`.
`site/index.html` is an additional standalone visual demo that opens without Python;
it only displays precomputed sample results and is not a substitute for exercising
the Python application's callbacks during the code demonstration.

## Deliverables and remaining facts

| Requirement | Prepared material | Final action needed |
|---|---|---|
| Runnable application | Code, minimal dependencies and demo runner | Rehearse on the presenting computer |
| Individual journal | `submission/JOURNAL.md` | Review the factual record; add the actual rehearsal and submission commit |
| Project plan | `submission/PROJECT_PLAN.md` | Sole owner assigned: Zimiao Xiang; adjust dates to the final course deadline |
| GitHub commits/share | `submission/GITHUB_HANDOFF.md` | Fetch/Pull, review, Commit/Push through Desktop, share repository |
| Weekly progress summary | `submission/WEEKLY_MEETING.md` | Confirm the solo format with the instructor and send the reviewed summary |

These materials have not been committed/pushed by this preparation step. No invitation
has been sent to Fatcat1015, and no message has been posted to the group chat.

## 中文使用提示

本次代码演示请启动本地 Python 应用，并现场点击完成选角流程。
本项目只有一位成员，日志和后续计划均按个人项目整理。每周材料为个人进度总结，
请向老师确认是否满足会议要求。提交前请按老师要求，
在 GitHub Desktop 先 Fetch/Pull，再操作、测试、Commit 和 Push。
详细交接步骤见 `submission/GITHUB_HANDOFF.md`。
