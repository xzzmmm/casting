"""Run the local coursework demo with explicit sample-data mode."""
from __future__ import annotations

import argparse
import os
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description="CastingNuwa coursework demo")
    parser.add_argument("--port", type=int, default=7860)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--check", action="store_true", help="Build the UI and exit")
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("--port must be between 1 and 65535")

    os.chdir(Path(__file__).resolve().parent)
    # A configured key must not turn a coursework demo into a paid API call.
    # The .env loader preserves existing environment variables.
    os.environ["LLM_API_KEY"] = ""
    os.environ["GRADIO_ANALYTICS_ENABLED"] = "False"

    try:
        from app import build_ui
        from ui_theme import THEME_CSS, create_theme
    except ImportError as exc:
        raise SystemExit(
            "Missing dependency. Run: python -m pip install -r requirements_demo.txt\n"
            f"Details: {exc}"
        ) from exc

    demo = build_ui()
    if args.check:
        config = demo.get_config_file()
        print(f"DEMO CHECK OK: {len(config['components'])} components, "
              f"{len(config['dependencies'])} event bindings.")
        return

    print("CastingNuwa DEMO: sample-data mode; no external AI calls.")
    print(f"Open http://127.0.0.1:{args.port}; Ctrl+C stops the application.")
    demo.launch(
        server_name="127.0.0.1",
        server_port=args.port,
        share=False,
        inbrowser=not args.no_browser,
        theme=create_theme(),
        css=THEME_CSS,
    )


if __name__ == "__main__":
    main()
