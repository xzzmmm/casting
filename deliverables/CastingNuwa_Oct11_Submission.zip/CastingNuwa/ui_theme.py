"""CastingNuwa 的视觉主题；不依赖业务状态或模型调用。"""

from html import escape

import gradio as gr


HERO_HTML = """
<div class="nuwa-brandbar">
  <div class="nuwa-brand"><span class="nuwa-monogram" aria-hidden="true">N</span>
    <span>CastingNuwa <small>选角女娲</small></span></div>
  <span class="nuwa-edition">CASTING STUDIO · V0.6</span>
</div>
<div class="nuwa-hero">
  <div class="nuwa-eyebrow">从剧本，到舞台</div>
  <h1>让每个角色，<br class="nuwa-mobile-break">找到合适的表演者。</h1>
  <p>整理角色、设计试镜、记录观察。把每一次创作选择，留下清晰的依据。</p>
  <div class="nuwa-hero-note"><span></span> AI 整理观察，最终判断由导演完成</div>
</div>
"""


def empty_state(title: str, description: str, tag: str = "WORKSPACE") -> str:
    """所有结果区使用一致的占位样式；动态文本先转义。"""
    return (
        '<div class="nuwa-empty">'
        f'<div class="nuwa-empty-tag">{escape(tag)}</div>'
        '<div class="nuwa-empty-rule" aria-hidden="true"></div>'
        f'<h3>{escape(title)}</h3><p>{escape(description)}</p></div>'
    )


def create_theme():
    """与自定义 CSS 同步的 Gradio 控件主题，包含深色模式。"""
    return gr.themes.Soft(
        primary_hue="rose", secondary_hue="stone", neutral_hue="stone",
        font=["Inter", "PingFang SC", "Microsoft YaHei", "sans-serif"],
    ).set(
        body_background_fill="#f7f5f1",
        body_background_fill_dark="#211e1c",
        body_text_color="#292725",
        body_text_color_dark="#eee8df",
        block_background_fill="#fffdfa",
        block_background_fill_dark="#2c2724",
        block_border_color="#e6dfd6",
        block_border_color_dark="#463d36",
        block_label_text_color="#5d5650",
        block_label_text_color_dark="#c9beb2",
        input_background_fill="#faf8f5",
        input_background_fill_dark="#241f1c",
        input_border_color="#e2dacf",
        input_border_color_dark="#51463e",
        input_placeholder_color="#8b8279",
        input_placeholder_color_dark="#b5a79a",
        button_primary_background_fill="#743d43",
        button_primary_background_fill_dark="#9b5b64",
        button_primary_background_fill_hover="#5c3036",
        button_primary_background_fill_hover_dark="#ad6b75",
        button_primary_text_color="#ffffff",
        button_primary_text_color_dark="#ffffff",
        button_primary_border_color="#743d43",
        button_primary_border_color_dark="#9b5b64",
        button_secondary_background_fill="#fffdfa",
        button_secondary_background_fill_dark="#302923",
        button_secondary_text_color="#5d5650",
        button_secondary_text_color_dark="#eee8df",
        button_secondary_border_color="#e2dacf",
        button_secondary_border_color_dark="#51463e",
        border_color_primary="#e6dfd6",
        border_color_primary_dark="#463d36",
        border_color_accent="#a67970",
        border_color_accent_dark="#c49086",
    )


THEME_CSS = """
#nuwa-workspace {
  --nuwa-ink: #292725;
  --nuwa-muted: #69635f;
  --nuwa-wine: #743d43;
  --nuwa-gold: #9a7548;
  --nuwa-paper: #f7f5f1;
  --nuwa-surface: #fffdfa;
  --nuwa-field: #faf8f5;
  --nuwa-line: #e6dfd6;
  --nuwa-hint: #fbf4e9;
  --nuwa-hint-text: #765b34;
  --nuwa-shadow: 0 12px 36px rgba(61, 45, 30, .045);
  max-width: 1280px !important;
  margin: 0 auto;
  padding: 28px 34px 24px !important;
  background: var(--nuwa-paper);
  color: var(--nuwa-ink);
}
.dark #nuwa-workspace, #nuwa-workspace.dark {
  --nuwa-ink: #eee8df;
  --nuwa-muted: #bdb1a5;
  --nuwa-wine: #d19a9e;
  --nuwa-gold: #c1a174;
  --nuwa-paper: #211e1c;
  --nuwa-surface: #2c2724;
  --nuwa-field: #241f1c;
  --nuwa-line: #463d36;
  --nuwa-hint: #352c20;
  --nuwa-hint-text: #e0c499;
  --nuwa-shadow: 0 12px 36px rgba(0, 0, 0, .08);
}
#nuwa-workspace .nuwa-brandbar {
  display: flex; align-items: center; justify-content: space-between;
  gap: 16px; padding-bottom: 20px; border-bottom: 1px solid var(--nuwa-line);
}
#nuwa-workspace .nuwa-brand { display: flex; align-items: center; gap: 12px; font-size: 17px; font-weight: 600; letter-spacing: .02em; }
#nuwa-workspace .nuwa-brand small { display: block; font-size: 11px; color: var(--nuwa-muted); font-weight: 400; letter-spacing: .16em; margin-top: 1px; }
#nuwa-workspace .nuwa-monogram {
  display: grid; place-items: center; width: 38px; height: 38px;
  background: #743d43; color: #fff6e8; font: italic 26px Georgia, serif;
  border-radius: 9px 2px 9px 2px;
}
#nuwa-workspace .nuwa-edition { font-size: 10px; letter-spacing: .16em; color: var(--nuwa-muted); }
#nuwa-workspace .nuwa-hero { padding: 34px 0 28px; }
#nuwa-workspace .nuwa-eyebrow { color: var(--nuwa-gold); font-size: 12px; letter-spacing: .18em; margin-bottom: 12px; }
#nuwa-workspace .nuwa-hero h1 {
  color: var(--nuwa-ink); font-family: "Noto Serif SC", "Songti SC", "SimSun", serif;
  font-size: clamp(28px, 3.5vw, 40px); font-weight: 600; letter-spacing: .04em;
  line-height: 1.4; margin: 0 0 12px;
}
#nuwa-workspace .nuwa-hero p { color: var(--nuwa-muted); font-size: 14px; line-height: 1.8; margin: 0; }
#nuwa-workspace .nuwa-hero-note { display: flex; align-items: center; gap: 8px; margin-top: 18px; color: var(--nuwa-muted); font-size: 12px; }
#nuwa-workspace .nuwa-hero-note span { width: 5px; height: 5px; border-radius: 50%; background: var(--nuwa-gold); }
#nuwa-workspace .nuwa-mobile-break { display: none; }
#nuwa-workspace .mock-banner {
  background: var(--nuwa-hint) !important; color: var(--nuwa-hint-text) !important;
  border: 1px solid var(--nuwa-line); border-radius: 8px;
  padding: 11px 16px; font-size: 12px;
}
#nuwa-workspace .mock-banner p { margin: 0; }
#nuwa-workspace .project-tools { border: 1px solid var(--nuwa-line); border-radius: 9px; background: var(--nuwa-surface); }
#nuwa-workspace .global-notice:empty { display: none; }
#nuwa-workspace #workflow-tabs { margin-top: 10px; border: 0; }
#nuwa-workspace #workflow-tabs > .tab-nav {
  gap: 3px; flex-wrap: wrap; padding: 5px 0 0;
  border-bottom: 1px solid var(--nuwa-line); margin-bottom: 22px;
}
#nuwa-workspace #workflow-tabs > .tab-nav button {
  padding: 12px 15px; color: var(--nuwa-muted); background: transparent;
  border: 0; border-bottom: 2px solid transparent; border-radius: 0;
  font-size: 13px; transition: color .15s ease;
}
#nuwa-workspace #workflow-tabs > .tab-nav button:hover { color: var(--nuwa-wine); }
#nuwa-workspace #workflow-tabs > .tab-nav button[aria-selected="true"] {
  color: var(--nuwa-wine); border-bottom-color: var(--nuwa-wine); font-weight: 600;
}
#nuwa-workspace .tabitem { padding: 0; border: 0; background: transparent; }
#nuwa-workspace .step-heading { margin-bottom: 8px; }
#nuwa-workspace .step-heading h3 { font-size: 20px; font-weight: 600; color: var(--nuwa-ink); margin: 0 0 5px; }
#nuwa-workspace .step-description { color: var(--nuwa-muted); margin-bottom: 12px; }
#nuwa-workspace .step-description p { font-size: 13px; line-height: 1.8; }
#nuwa-workspace .workspace-row { gap: 20px; align-items: stretch; }
#nuwa-workspace .input-panel, #nuwa-workspace .output-panel {
  background: var(--nuwa-surface); border: 1px solid var(--nuwa-line);
  border-radius: 12px; padding: 20px; box-shadow: var(--nuwa-shadow);
}
#nuwa-workspace .panel-title h3 { margin: 0; font-size: 15px; color: var(--nuwa-ink); }
#nuwa-workspace .panel-title p { color: var(--nuwa-muted); font-size: 12px; margin: 4px 0 12px; }
#nuwa-workspace .input-panel .form { border: 0; background: transparent; box-shadow: none; }
#nuwa-workspace .input-panel .block { border-radius: 8px; }
#nuwa-workspace textarea { line-height: 1.85; }
#nuwa-workspace button.primary { font-weight: 500; border-radius: 8px; min-height: 44px; }
#nuwa-workspace button.secondary { font-weight: 400; border-radius: 8px; }
#nuwa-workspace .button-row { gap: 8px; }
#nuwa-workspace .nuwa-result { color: var(--nuwa-ink); }
#nuwa-workspace .nuwa-result h2 { font-family: "Noto Serif SC", "Songti SC", serif; font-size: 24px; margin-top: 16px; color: var(--nuwa-ink); }
#nuwa-workspace .nuwa-result h3 { font-size: 15px; margin-top: 22px; color: var(--nuwa-wine); }
#nuwa-workspace .nuwa-result p, #nuwa-workspace .nuwa-result li { font-size: 13px; line-height: 1.85; }
#nuwa-workspace .nuwa-result blockquote { border-left: 2px solid var(--nuwa-gold); color: var(--nuwa-muted); background: var(--nuwa-field); padding: 10px 14px; border-radius: 0 6px 6px 0; }
#nuwa-workspace .nuwa-result hr { border-color: var(--nuwa-line); margin: 24px 0; }
#nuwa-workspace .nuwa-result table { font-size: 13px; }
#nuwa-workspace .nuwa-empty { padding: 54px 16px; text-align: center; }
#nuwa-workspace .nuwa-empty-tag { color: var(--nuwa-gold); font-size: 10px; letter-spacing: .2em; }
#nuwa-workspace .nuwa-empty-rule { width: 28px; height: 1px; background: var(--nuwa-line); margin: 18px auto; }
#nuwa-workspace .nuwa-empty h3 { color: var(--nuwa-ink); font-size: 17px; font-weight: 500; margin: 0 0 10px; }
#nuwa-workspace .nuwa-empty p { color: var(--nuwa-muted); font-size: 13px; line-height: 1.8; max-width: 280px; margin: 0 auto; }
#nuwa-workspace .raw-data { margin-top: 14px; border-color: var(--nuwa-line); background: var(--nuwa-field); border-radius: 8px; }
#nuwa-workspace .nuwa-footer { display: flex; justify-content: space-between; gap: 12px; border-top: 1px solid var(--nuwa-line); margin-top: 32px; padding-top: 18px; color: var(--nuwa-muted); font-size: 11px; letter-spacing: .02em; }
@media (max-width: 768px) {
  #nuwa-workspace { padding: 20px 18px !important; }
  #nuwa-workspace .nuwa-edition { font-size: 9px; letter-spacing: .06em; }
  #nuwa-workspace .nuwa-hero { padding: 24px 0 22px; }
  #nuwa-workspace .workspace-row { gap: 14px; }
  #nuwa-workspace .input-panel, #nuwa-workspace .output-panel { padding: 16px; min-width: min(100%, 300px) !important; }
  #nuwa-workspace #workflow-tabs > .tab-nav button { padding: 10px 12px; }
  #nuwa-workspace .nuwa-footer { flex-wrap: wrap; }
}
@media (max-width: 480px) {
  #nuwa-workspace { padding: 16px 12px !important; }
  #nuwa-workspace .nuwa-mobile-break { display: initial; }
  #nuwa-workspace .nuwa-brand { font-size: 15px; }
  #nuwa-workspace .nuwa-edition { max-width: 105px; text-align: right; line-height: 1.8; }
  #nuwa-workspace textarea, #nuwa-workspace input { font-size: 16px; }
  #nuwa-workspace .nuwa-empty { padding: 32px 8px; }
}
@media (prefers-reduced-motion: reduce) {
  #nuwa-workspace * { transition: none !important; }
}
"""
