# CastingNuwa · GitHub Pages 演示版

这是无需 Python 后端、无需 API Key 的静态演示网站。支持切换六步流程、
查看示例角色卡 / 试镜任务 / 演员观察 / 候选与制作团队结果，
以及下载示例项目 JSON 和试镜任务 Markdown。

页面始终标注演示模式，不分析输入的剧本，不处理媒体上传，不自动确认真实选角。
完整 Python 应用和视觉主题保留在项目根目录。

## 直接查看

下载后用浏览器打开 `site/index.html`。

## GitHub Pages 发布

1. 把 `site/` 和 `.github/workflows/pages.yml` 放到仓库根目录。
2. 在仓库 Settings → Pages，将 Source 选择为 GitHub Actions。
3. 推送到 `main`，或在 Actions 中手动运行 “Publish CastingNuwa demo”。
4. 工作流部署成功后，在 Pages 或 workflow deployment 中查看生成的网址。

若账号使用 GitHub Free，通常需使用公开仓库。代码中没有 API 密钥。

也可以不用 Actions：将 `site/index.html` 放在一个演示仓库根目录，
在 Settings → Pages 选择 Deploy from a branch、`main`、`/(root)`。
